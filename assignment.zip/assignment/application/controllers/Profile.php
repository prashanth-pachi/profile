<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

    function __construct() {
        parent::__construct();

        $this->load->model('user_model');
    }

    public function index() {
        $this->load->view('profile');
    }

    public function save() {
        $formdata = $this->security->xss_clean($_POST);
        $userData = [];
        if (isset($formdata['register'])) {
            $uploadfile = "assets/images/profile.jpg";
            if (!empty($_FILES['file']) && $_FILES['file']['error'] == 0) {

                $uploaddir = 'assets/images/';
                $verifyimg = getimagesize($_FILES['file']['tmp_name']);

                $pattern = "#^(image/)[^\s\n<]+$#i";

                if (!preg_match($pattern, $verifyimg['mime'])) {
                    die("Only image files are allowed!");
                }

                $uploadfile = $uploaddir . time() . '_' . $_FILES['file']['name'];
                if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)) {
                    $this->session->set_flashdata('message', 'User Data saved succesfully !');
                }
            }

            $userData = Array('fname' => $formdata['fname'],
                'lname' => $formdata['lname'],
                'email' => $formdata['email'],
                'mobile' => $formdata['mobile'],
                'address1' => $formdata['address1'],
                'address2' => $formdata['address2'],
                'city' => $formdata['city'],
                'state' => $formdata['state'],
                'country' => $formdata['country'],
                'zip' => $formdata['zipCode'],
                'profile_img' => $uploadfile
            );

            $this->user_model->insert($userData);
        }
        $this->load->view('profile', $userData);

        $this->load->view('profile_pdf', $userData, true);
        $html = $this->load->view('profile_pdf', $userData, true);

        //        prepare tcpdf

        $this->load->library("Pdf");
// create new PDF document
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('user');
        $pdf->SetTitle('Profile');
        $pdf->SetSubject('multilingual profile');
        $pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set header and footer fonts
        $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
        $pdf->setImageScale(5);
// set some language dependent data:
        $lg = Array();

// set some language-dependent strings (optional)
        $pdf->setLanguageArray($lg);
// remove lines 
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);

// add a page
        $pdf->AddPage();
// set font
        $pdf->SetFont('dejavusans', '', 12);
        $pdf->SetFont('kozminproregular', '', 12);
        $pdf->writeHTML($html, true, false, true, false, '');
        $pdf->Output('profile.pdf','I');               
    }

}
