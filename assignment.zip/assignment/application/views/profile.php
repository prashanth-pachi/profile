<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>PROFILE</title>

        <style type="text/css">

            ::selection { background-color: #E13300; color: white; }
            ::-moz-selection { background-color: #E13300; color: white; }
            
            #container {
                margin: 10px;
                border: 1px solid #D0D0D0;
                box-shadow: 0 0 8px #D0D0D0;
                margin-left: 30px;
                margin-right: 30px;
                margin-bottom: 10px;
                padding: 18px;
            }
            
            body {
                background-color: #fff;
                margin: 40px;
                font: 13px/20px normal Helvetica, Arial, sans-serif;
                color: #4F5155;
            }          

            #body {
                margin: 0 15px 0 15px;
            }
            img {
                border-radius: 50%;
                width :200px;
                height:200px;
                margin-top: 10px;
                margin-bottom: 10px;                
            }

            p.footer {
                text-align: right;
                font-size: 11px;
                border-top: 1px solid #D0D0D0;
                line-height: 32px;
                padding: 0 10px 0 10px;
                margin: 20px 0 0 0;
            }


        </style>
        <script src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">	               
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css">	       
        <script src="<?php echo base_url(); ?>assets/js/jquery-2.2.3.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrapValidator.min.js"></script>        
         <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script>
    </head>
    <body>
        <div class = "container-" >
            <h1 class="text-center"> Profile Page</h1>
            <hr>
            <?php $attributes = array('class' => 'Registration', 'id' => 'Registration'); ?>
            <?php echo form_open_multipart('profile/save', $attributes);?>
            <div class = "row" >
                <div class = "col-md-offset-3 col-md-6 " >
                    <div  id="genral_info" class = "form-group col-md-6 col-sm-6" >
                        
                            <label > First Name: </label>
                            <input type = "text" id = "fname" name = "fname" class = "form-control" placeholder = "First Name" required = "" value = "<?php if(isset($fname)){  echo $fname; } ?>" >

                            <label > Last Name: </label>
                            <input type = "text" id = "lname" name = "lname" class = "form-control" placeholder = "Last Name" required = "" value = "<?php if(isset($lname)){  echo $lname; } ?>" >

                            <label > Email </label>
                            <input type = "email" id = "email" name = "email" class = "form-control" placeholder = "Email" required = "" value = "<?php if(isset($email)){  echo $email; } ?>" >       

                            <label > Mobile No </label>
                            <input type = "text" id = "mobile" name = "mobile" class = "form-control" placeholder = "mobile"  required = "" value = "<?php if(isset($mobile)){  echo $mobile; } ?>" >                        
                        
                    </div>
                    <div id="profile_pic" class = "form-group col-md-6 col-sm-6">

                        <img src="<?php if(isset($profile_img)){ echo base_url().$profile_img; } else { echo base_url().'assets/images/profile.jpg'; }?>" id="profile-img-tag"/>
                             
                        <input type="file" name="file" id="profile-img">

                    </div>                                    
                    <div class = "form-group col-md-12" >                 
                        <label > Address 1: </label>
                        <input type = "text" id = "address1" name = "address1" class = "form-control" placeholder = "Address" required = "" value = "<?php if(isset($address1)){  echo $address1; } ?>" >
                        <label > Address 2: </label>
                        <input type = "text" id = "address2" name = "address2" class = "form-control" placeholder = "Address" required = "" value = "<?php if(isset($address2)){  echo $address2; } ?>" >

                        <label > City: </label>
                        <input type = "text" id = "city" name = "city" class = "form-control" placeholder = "city" required = "" value = "<?php if(isset($city)){  echo $city; } ?>" >

                        <label > State </label>
                        <input type = "text" id = "state" name = "state" class = "form-control" placeholder = "state" required = "" value = "<?php if(isset($state)){  echo $state; } ?>" >       

                        <label > Country </label>
                        <input type = "text" id = "country" name = "country" class = "form-control" placeholder = "Country"  required = "" value = "<?php if(isset($country)){  echo $country; } ?>" >               
                        <label > Zipcode </label>
                        <input type = "text" id = "zipCode" name = "zipCode" class = "form-control" placeholder = "ZipCode"  required = "" value = "<?php if(isset($zip)){  echo $zip; } ?>" >               
                    </div>
                    <input  type = "submit" value = "Register" id = "register" name = "register" class = "btn btn-lg btn-success btn-block" > <br/>                   
                </div>
            </div>                         
            <?php echo form_close(); ?>
        </div>

        <script type="text/javascript">
//            image load after selection
    
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function (e) {
                        $('#profile-img-tag').attr('src', e.target.result);
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }
            $("#profile-img").change(function () {
                readURL(this);
            });
        </script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/form_validation.js"></script>

    </body>
</html>
