<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>PROFILE</title>
        <script src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">	               
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css">	       
        <script src="<?php echo base_url(); ?>assets/js/jquery-2.2.3.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrapValidator.min.js"></script>        
    </head>
    <body>
        <div class = "container-" >
            <h1 class="text-center"> Profile Page</h1>
            <hr>            
            <?php echo form_open();?>
            <div class = "row" >
                <div class = "col-md-offset-3 col-md-6 " >
                    <div id="profile_pic" class = "form-group col-md-4 col-sm-4">

                        <img src="<?php if(isset($profile_img)){ echo base_url().$profile_img; } else { echo base_url().'assets/images/profile.jpg'; }?>" id="profile-img-tag"/>                             
                      

                    </div>                     
                    <div  id="genral_info" class = "form-group col-md-8 col-sm-8" >                         
                            <label > Name: </label>   
                          
                            <label> <?php if(isset($fname)){  echo $fname; }if(isset($lname)){  echo ' '.$lname; } ?></label>
                            <br>     <br>                                       
                            <label > Email: </label>                         
                            <label> <?php if(isset($email)){  echo $email; } ?> </label>  <br> <br>                            
                            <label > Mobile No: </label>  
                            <label> <?php if(isset($mobile)){  echo $mobile; } ?> </label>                  
                    </div>
                    
                     </div>
                    <div class = "form-group col-md-12" >                 
                        <label > Address: </label>
                        <label> <?php if(isset($address1)){  echo $address1; } ?> </label> <br> <br>                             
                        <label> <?php if(isset($address2)){  echo str_repeat('&nbsp;', 18).$address2; } ?> </label> <br> <br>      

                        <label > City: </label>
                        <label> <?php if(isset($city)){  echo $city; } ?> </label> <br> <br>      

                        <label > State: </label>
                        <label> <?php if(isset($state)){  echo $state; } ?> </label> <br> <br>      

                        <label > Country: </label>
                        <label> <?php if(isset($country)){  echo $country; } ?></label> <br> <br>      
                        <label > Zip: </label>
                        <label> <?php if(isset($zip)){  echo $zip; } ?> </label> <br> <br>      
                    </div>                    
                </div>
            </div>                         
            <?php echo form_close(); ?>
    </body>
</html>
