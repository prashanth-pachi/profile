﻿-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2018 at 04:39 PM
-- Server version: 5.6.11
-- PHP Version: 5.5.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `assignment`
--
CREATE DATABASE IF NOT EXISTS `assignment` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `assignment`;

-- --------------------------------------------------------

--
-- Table structure for table `usermaster`
--

CREATE TABLE IF NOT EXISTS `usermaster` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `fname` varchar(256) CHARACTER SET utf8 NOT NULL,
  `lname` varchar(256) CHARACTER SET utf8 NOT NULL,
  `email` varchar(256) CHARACTER SET utf8 NOT NULL,
  `mobile` varchar(15) CHARACTER SET utf8 NOT NULL,
  `address1` varchar(256) CHARACTER SET utf8 NOT NULL,
  `address2` varchar(256) CHARACTER SET utf8 NOT NULL,
  `city` varchar(50) CHARACTER SET utf8 NOT NULL,
  `state` int(11) NOT NULL,
  `country` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `profile_img` varchar(256) DEFAULT NULL,
  `createdby` varchar(256) NOT NULL,
  `createdon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `usermaster`
--

INSERT INTO `usermaster` (`id`, `fname`, `lname`, `email`, `mobile`, `address1`, `address2`, `city`, `state`, `country`, `zip`, `profile_img`, `createdby`, `createdon`) VALUES
(1, 'Prashanth ', 'kumar', 'pachi01011987@gmail.com', '9738964289', ' 事实上，我是想在自己的QQ空间写一段序言，我想了很久才想到这两三句话，但又觉得中文看起来不太好，所以也许把它翻译成英文会有诗意一点。所以在这里谢谢大家的帮助~~', ' это мой адрес Пара небольших параграфов, чтобы объяснить, почему единица тепла называется ватт и откуда она взялась.', 'لَو ضَاق صَدري قِلت مَا أطوَلكِ يَا ليل الله يعينَ', 0, 0, 560060, 'assets/images/profile.jpg', '', '2018-07-30 18:25:06'),
(2, 'Prashanth ', 'kumar', 'pachi01011987@gmail.com', '9738964289', ' 事实上，我是想在自己的QQ空间写一段序言，我想了很久才想到这两三句话，但又觉得中文看起来不太好，所以也许把它翻译成英文会有诗意一点。所以在这里谢谢大家的帮助~~', ' это мой адрес Пара небольших параграфов, чтобы объяснить, почему единица тепла называется ватт и откуда она взялась.', 'لَو ضَاق صَدري قِلت مَا أطوَلكِ يَا ليل الله يعينَ', 0, 0, 560060, 'assets/images/1532957130_img.jpg', '', '2018-07-30 18:25:30'),
(4, 'tabsheer', 'a', 'tab@gmai.com', '9696969696', ' 事实上，我是想在自己的QQ空间写一段序言，我想了很久才想到这两三句话，但又觉得中文看起来不太好，所以也许把它翻译成英文会有诗意一点。所以在这里谢谢大家的帮助~~', 'это мой адрес Пара небольших параграфов, чтобы объяснить, почему единица тепла называется ватт и откуда она взялась.', 'ق صَدري قِلت مَا أطوَلكِ يَا ليل الله يعينَ', 123, 132, 31212321, 'assets/images/profile.jpg', '', '2018-07-30 18:32:04'),
(5, '123', '123', '132@gmai.com', '9696969696', ' 事实上，我是想在自己的QQ空间写一段序言，我想了很久才想到这两三句话，但又觉得中文看起来不太好，所以也许把它翻译成英文会有诗意一点。所以在这里谢谢大家的帮助~~', 'это мой адрес Пара небольших параграфов, чтобы объяснить, почему единица тепла называется ватт и откуда она взялась.', 'ق صَدري قِلت مَا أطوَلكِ يَا ليل الله يعينَ', 123, 132, 31212321, 'assets/images/profile.jpg', '', '2018-07-30 18:32:47'),
(6, 'Rajesh', 'krishnan', '132@gmai.com', '9696969696', ' 事实上，我是想在自己的QQ空间写一段序言，我想了很久才想到这两三句话，但又觉得中文看起来不太好，所以也许把它翻译成英文会有诗意一点。所以在这里谢谢大家的帮助~~', 'это мой адрес Пара небольших параграфов, чтобы объяснить, почему единица тепла называется ватт и откуда она взялась.', 'ق صَدري قِلت مَا أطوَلكِ يَا ليل الله يعينَ', 0, 0, 560060, 'assets/images/1532957748_img.jpg', '', '2018-07-30 18:35:48');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
