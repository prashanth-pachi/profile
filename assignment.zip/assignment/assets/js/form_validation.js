/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 $().ready(function() {
           jQuery.validator.addMethod("mail", function(value, element) {
                return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,3}$/i.test(value);
            }, "Your email address must be in the format of name@domain.com.");
            
              $.validator.addMethod("mobileNo",function(value,element){
                return this.optional(element) || /^[6-9][0-9].{0,9}$/i.test(value);
            },"mobile starts with minimum 6 and are 9-10 number inlength");

            
        });
        
$("#Registration").validate({
  rules: {
    fname: {
        required:true,
         minlength: 3
    },
    lname: {
        required:true,
         minlength:1
    },
    email: {
      required: true,
      mail:true,
      email: true,    
    },
    mobile: {
        required:true,
        number:true,
        mobileNo:true,
        minlength: 9,
        maxlength: 10        
    },
    address1: {
        required:true
    },
    address2: {
        required:true
    },
    city: {
        required:true
    },
    state: {
        required:true
    },
    country: {
        required:true
        
    },
    zipCode: {
        required:true,
        number:true,
        minlength:6
         
    }
  },
  messages: {
    fname: {
      required: "Please enter your name.",
      fname: "Name should contain minimum 3 chars <br/>"
    },
    lname: {
      required: "Please enter your name.",
      lname: "Name should contain minimum 3 chars."
    },
    email: {
      required: "We need your email address to contact you.",
      email: "Your email address must be in the format of name@domain.com."
    },
    mobile: {
      required: "We need your mobile number"      
    }
  }
});
